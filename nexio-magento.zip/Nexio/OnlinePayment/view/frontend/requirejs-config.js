var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/select-payment-method':
               'Nexio_OnlinePayment/js/action/payment/select-payment-method',
            'Magento_Checkout/js/action/place-order':
               'Nexio_OnlinePayment/js/action/place-order',
            'Nexio_OnlinePayment/js/jsencrypt':'Nexio_OnlinePayment/js/jsencrypt',
            vaultpayment: 'Nexio_OnlinePayment/js/vault-payment/vault'
        }
    }
};